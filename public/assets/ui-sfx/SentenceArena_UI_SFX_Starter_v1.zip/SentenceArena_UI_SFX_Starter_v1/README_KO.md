# SentenceArena UI 효과음 테스트 세트 v1

9종의 직접 제작한 원본 샘플입니다. **Kenney에서 다운로드받은 파일은 아닙니다.** 이 실행 환경에서 외부 ZIP 파일 다운로드가 불가능해, 바로 사용할 수 있는 테스트 음원을 별도 제작했습니다. 48kHz 스테레오 WAV / OGG를 각각 수록했습니다.

## 추천 매핑

| 동작 | OGG 파일 |
|---|---|
| 모든 일반 클릭 (과용 주의) | 01_ui_click.ogg |
| 게시판 전환·진입 | 02_board_navigate.ogg |
| 영토 지도 선택 | 03_territory_select.ogg |
| 프로필 열기 | 04_profile_open.ogg |
| 탭 전환 | 05_tab_switch.ogg |
| 좋아요·공감 | 06_reaction.ogg |
| 투표 완료 | 07_vote_confirm.ogg |
| 업적 획득 | 08_achievement_unlocked.ogg |
| 오류·권한 거부 | 09_soft_error.ogg |

## 연결 지침

- 우선 미리 듣고 3~5개만 사용해보세요.
- 효과음 기본 활성화 및 초기 음량은 사용자 설정과 브라우저 자동 재생 규정을 고려하세요.
- 모든 클릭 이벤트에 포괄적으로 연결하지 말고 의도된 UI 동작에만 연결하세요.
- 기본 볼륨은 0.15~0.30 사이에서 시작하고 전체 음량 설정과 음소거를 제공하세요.
- 80ms 내 중복 클릭은 재생을 제한하고, 페이지 이탈/해제 시 오디오를 정리하세요.
- 업적 MP4 자체 음향이 있는 경우 08을 동시에 재생하지 마세요.
- 기존 업적 영상과 새 효과음의 피크가 겹치지 않도록 테스트하세요.
- /kr /us 동일 매핑, 텍스트만 번역.
- NAVER Cloud/운영 Supabase/운영 배포 변경 금지.

## 별도로 확인한 CC0 라이브러리

- https://kenney.nl/assets/interface-sounds
- https://kenney.nl/assets/ui-audio

위 라이브러리 음원을 사용하려면 별도로 다운로드해서 실제 청음하고 교체해야 합니다.
